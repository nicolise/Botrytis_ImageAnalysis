# nocov start
getNumberOfFrames <- function(...) {
  .Defunct(new = "numberOfFrames")
}
# nocov end
