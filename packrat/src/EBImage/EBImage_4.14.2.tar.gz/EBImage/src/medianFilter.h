#ifndef EBIMAGE_MEDIANFILTER_H
#define EBIMAGE_MEDIANFILTER_H

#include <R.h>
#include <Rdefines.h>

#ifdef __cplusplus
extern "C" {
#endif

SEXP medianFilter (SEXP, SEXP, SEXP);

#ifdef __cplusplus
};
#endif

#endif
