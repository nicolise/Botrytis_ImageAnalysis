.onLoad <- function(libname, pkgname) {
  library.dynam("DNAcopy", pkgname, libname)
}
